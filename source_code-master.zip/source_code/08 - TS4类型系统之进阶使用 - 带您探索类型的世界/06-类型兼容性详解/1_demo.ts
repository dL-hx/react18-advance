// let a: number = 123;
// let b: number = 456;

// b = a;

// let a: number = 123;
// let b: string = 'hello';

// b = a;

//let a: number = 123;
//let b: string | number = 'hello';
//b = a;  // success
//a = b;  // error

//let a: {username: string} = { username: 'xiaoming' };
//let b: {username: string; age: number} = { username: 'xiaoming', age: 20 };
//a = b; // success
//b = a;  // error

// function foo(n: { username: string }) {}
// foo({ username: 'xiaoming' }) // success
// foo({ username: 'xiaoming', age: 20 }) // error
// let a = { username: 'xiaoming', age: 20 }
// foo(a) // success
