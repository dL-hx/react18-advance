
let a = 123;
a = 'hello';