
// import moment from 'moment' 

// import { a } from './4_demo'

// debugger;
// let a = 123;

function foo(n: any){

}

let div: HTMLDivElement | null = document.querySelector('div');