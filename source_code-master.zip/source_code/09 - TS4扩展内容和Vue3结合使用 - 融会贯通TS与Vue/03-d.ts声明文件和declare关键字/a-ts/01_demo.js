"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.foo = void 0;
function foo(n) {
    console.log(n);
}
exports.foo = foo;
