export function foo(n: number) {
  console.log(n)
}
