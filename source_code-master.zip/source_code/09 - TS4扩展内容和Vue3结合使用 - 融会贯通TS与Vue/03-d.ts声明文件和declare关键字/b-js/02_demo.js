let { foo } = require('./01_demo')

foo('hello')
