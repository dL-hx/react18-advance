import { foo } from './01_demo'

foo(123)
foo('hello')
