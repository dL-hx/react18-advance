export declare function foo(n: number): void
