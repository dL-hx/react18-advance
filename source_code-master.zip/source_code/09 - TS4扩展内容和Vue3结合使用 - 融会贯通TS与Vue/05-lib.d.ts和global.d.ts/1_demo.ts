let body: HTMLBodyElement | null = document.querySelector('body')

let date: Date = new Date()

let a: A = 'hello'
