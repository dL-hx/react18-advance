type A = string
