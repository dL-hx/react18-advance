
let a: unknown = 'hello';
a = 123;
(a as []).map(()=>{})


let b: string|undefined = undefined;

b!.length