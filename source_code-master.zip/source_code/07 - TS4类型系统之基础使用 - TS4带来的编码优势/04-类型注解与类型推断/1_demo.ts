
//类型注解
//let a: string = 'hello'

// type A = string;
// let a: A = 'hello'

// a = 'hi'
// a = true;

// 类型推断：TS自动完成类型注解的过程
let a = 'hello'
a = 123;




