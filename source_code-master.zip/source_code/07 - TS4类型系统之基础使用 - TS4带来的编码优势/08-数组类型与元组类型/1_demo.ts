
//let arr1: (number|string)[] = [1, 2, 3, 'hello'];


//let arr2: Array<number> = [1, 2, 3];

let arr3: [number, string] = [1, 'hello'];

//arr3[2] = 2;  // error
