let bar = 123;

export {
  bar
};