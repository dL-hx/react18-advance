//TS默认是全局环境，只要文件使用模块化操作那么就会变成局部环境

// import { bar } from './3_demo'
// let foo = 321;
// console.log(foo + bar);

// let a = 123;
// a.map(()=>{})

// let a = 123;
// a = 'hello';

// let a = 1;
// if(a === 1 && a === 2) {

// }

let foo = 123;
let a = {
  username: 'xiaoming',
  age: 20
}
a.usename

export {};